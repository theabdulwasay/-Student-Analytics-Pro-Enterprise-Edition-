from flask import Blueprint, jsonify, request
from data.json_manager import JSONManager
from services.student_service import StudentService

student_bp = Blueprint('student_bp', __name__)
db_manager = JSONManager('students.json')

@student_bp.route('/students', methods=['GET'])
def get_all():
    students = db_manager.load()
    return jsonify([StudentService.process_student(s) for s in students])

@student_bp.route('/students', methods=['POST'])
def create():
    data = request.json
    students = db_manager.load()
    new_id = max([s['id'] for s in students], default=0) + 1
    
    new_student = {
        "id": new_id,
        "name": data.get('name'),
        "marks": data.get('marks', {})
    }
    
    students.append(new_student)
    db_manager.save(students)
    return jsonify(StudentService.process_student(new_student)), 201

@student_bp.route('/students/<int:s_id>', methods=['PUT'])
def update(s_id):
    data = request.json
    students = db_manager.load()
    
    for s in students:
        if s['id'] == s_id:
            s['name'] = data.get('name', s['name'])
            s['marks'] = data.get('marks', s['marks'])
            db_manager.save(students)
            return jsonify(StudentService.process_student(s))
            
    return jsonify({"error": "Not found"}), 404

@student_bp.route('/students/<int:s_id>', methods=['DELETE'])
def delete_student(s_id):
    students = db_manager.load()
    new_list = [s for s in students if s['id'] != s_id]
    
    if len(new_list) == len(students):
        return jsonify({"error": "Not found"}), 404
        
    db_manager.save(new_list)
    return jsonify({"success": True})
