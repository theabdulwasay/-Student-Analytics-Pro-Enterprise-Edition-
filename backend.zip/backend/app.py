import json
import os
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

STUDENTS_FILE = 'students.json'

def load_students():
    if not os.path.exists(STUDENTS_FILE):
        return []
    with open(STUDENTS_FILE, 'r') as f:
        return json.load(f)

def save_students(students):
    with open(STUDENTS_FILE, 'w') as f:
        json.dump(students, f, indent=2)

def calculate_grade(average):
    if average >= 80: return 'A'
    elif average >= 60: return 'B'
    elif average >= 40: return 'C'
    else: return 'Fail'

def process_student_data(student):
    marks = student['marks']
    total_marks = sum(marks.values())
    average_marks = total_marks / len(marks)
    return {
        "id": student['id'],
        "name": student['name'],
        "marks": marks,
        "total_marks": total_marks,
        "average_marks": round(average_marks, 2),
        "grade": calculate_grade(average_marks)
    }

@app.route('/api/students', methods=['GET'])
def get_students():
    students = load_students()
    return jsonify([process_student_data(s) for s in students])

@app.route('/api/students', methods=['POST'])
def add_student():
    data = request.json
    students = load_students()
    
    # Simple ID generation
    new_id = max([s['id'] for s in students], default=0) + 1
    
    new_student = {
        "id": new_id,
        "name": data.get('name'),
        "marks": data.get('marks', {"math": 0, "physics": 0, "computer": 0, "english": 0})
    }
    
    students.append(new_student)
    save_students(students)
    return jsonify(process_student_data(new_student)), 201

@app.route('/api/students/<int:student_id>', methods=['PUT'])
def update_student(student_id):
    data = request.json
    students = load_students()
    
    for student in students:
        if student['id'] == student_id:
            student['name'] = data.get('name', student['name'])
            student['marks'] = data.get('marks', student['marks'])
            save_students(students)
            return jsonify(process_student_data(student))
            
    return jsonify({"error": "Student not found"}), 404

@app.route('/api/students/<int:student_id>', methods=['DELETE'])
def delete_student(student_id):
    students = load_students()
    updated_students = [s for s in students if s['id'] != student_id]
    
    if len(updated_students) == len(students):
        return jsonify({"error": "Student not found"}), 404
        
    save_students(updated_students)
    return jsonify({"message": "Student deleted successfully"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
