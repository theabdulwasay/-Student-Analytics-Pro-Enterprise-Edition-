class StudentService:
    @staticmethod
    def calculate_grade(average):
        if average >= 80: return 'A'
        elif average >= 70: return 'B'
        elif average >= 60: return 'C'
        elif average >= 50: return 'D'
        elif average >= 40: return 'E'
        else: return 'Fail'

    @classmethod
    def process_student(cls, student):
        marks = student.get('marks', {})
        if not marks:
            return {**student, "total_marks": 0, "average_marks": 0, "grade": "N/A"}
            
        total_marks = sum(marks.values())
        count = len(marks)
        average_marks = total_marks / count
        
        return {
            "id": student['id'],
            "name": student['name'],
            "marks": marks,
            "total_marks": total_marks,
            "max_marks": count * 100,
            "average_marks": round(average_marks, 2),
            "grade": cls.calculate_grade(average_marks)
        }
