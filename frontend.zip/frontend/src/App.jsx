import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { StudentProvider, useStudents } from './context/StudentContext';
import Sidebar from './layout/Sidebar';
import Dashboard from './pages/Dashboard';
import StudentDirectory from './pages/StudentDirectory';
import AddStudent from './pages/AddStudent';
import './index.css';

import LandingPage from './pages/LandingPage';
import './index.css';

function AppContent() {
  const { isLoggedIn } = useStudents();

  if (!isLoggedIn) {
    return (
      <Router>
        <Routes>
          <Route path="*" element={<LandingPage />} />
        </Routes>
      </Router>
    );
  }

  return (
    <Router>
      <div className="app-layout">
        <Sidebar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/students" element={<StudentDirectory />} />
            <Route path="/add" element={<AddStudent />} />
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function App() {
  return (
    <StudentProvider>
      <AppContent />
    </StudentProvider>
  );
}

export default App;
