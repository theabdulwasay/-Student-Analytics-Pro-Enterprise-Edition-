import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:5000/api',
});

export const StudentAPI = {
    getAll: () => api.get('/students'),
    create: (data) => api.post('/students', data),
    update: (id, data) => api.put(`/students/${id}`, data),
    delete: (id) => api.delete(`/students/${id}`),
};
