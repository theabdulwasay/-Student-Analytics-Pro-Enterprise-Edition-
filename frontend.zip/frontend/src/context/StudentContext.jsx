import React, { createContext, useState, useContext, useEffect } from 'react';
import { StudentAPI } from '../api/api';

const StudentContext = createContext();

export const useStudents = () => useContext(StudentContext);

export const StudentProvider = ({ children }) => {
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('isLoggedIn') === 'true');

    const refreshData = async () => {
        setLoading(true);
        try {
            const res = await StudentAPI.getAll();
            setStudents(res.data);
            setError(null);
        } catch (err) {
            setError('Could not connect to the backend server.');
        } finally {
            setLoading(false);
        }
    };

    const login = () => {
        setIsLoggedIn(true);
        localStorage.setItem('isLoggedIn', 'true');
    };

    const logout = () => {
        setIsLoggedIn(false);
        localStorage.setItem('isLoggedIn', 'false');
    };

    useEffect(() => {
        if (isLoggedIn) {
            refreshData();
        }
    }, [isLoggedIn]);

    return (
        <StudentContext.Provider value={{ students, loading, error, refreshData, isLoggedIn, login, logout }}>
            {children}
        </StudentContext.Provider>
    );
};
