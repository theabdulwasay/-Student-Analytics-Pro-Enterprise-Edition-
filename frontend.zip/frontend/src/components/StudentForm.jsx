import React, { useState, useEffect } from 'react';

const StudentForm = ({ onSubmit, initialData, onCancel }) => {
    const [formData, setFormData] = useState({
        name: '',
        marks: { math: 0, physics: 0, computer: 0, english: 0 }
    });

    useEffect(() => {
        if (initialData) {
            setFormData(initialData);
        }
    }, [initialData]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        if (name.includes('marks.')) {
            const subject = name.split('.')[1];
            setFormData(prev => ({
                ...prev,
                marks: { ...prev.marks, [subject]: parseInt(value) || 0 }
            }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="student-form">
            <div className="form-group">
                <label>Student Name</label>
                <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="Enter student name"
                />
            </div>
            <div className="marks-grid">
                {Object.keys(formData.marks).map(subject => (
                    <div className="form-group" key={subject}>
                        <label>{subject.charAt(0).toUpperCase() + subject.slice(1)}</label>
                        <input
                            type="number"
                            name={`marks.${subject}`}
                            value={formData.marks[subject]}
                            onChange={handleChange}
                            min="0"
                            max="100"
                            required
                        />
                    </div>
                ))}
            </div>
            <div className="form-actions">
                <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
                <button type="submit" className="btn-primary">
                    {initialData ? 'Update Student' : 'Add Student'}
                </button>
            </div>
        </form>
    );
};

export default StudentForm;
