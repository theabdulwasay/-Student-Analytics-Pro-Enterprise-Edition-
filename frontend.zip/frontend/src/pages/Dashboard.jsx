import React from 'react';
import { useStudents } from '../context/StudentContext';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { TrendingUp, Users, Award, AlertCircle } from 'lucide-react';

const Dashboard = () => {
    const { students, loading } = useStudents();

    if (loading) return <div className="p-8">Loading Analytics...</div>;

    const stats = {
        total: students.length,
        avg: (students.reduce((a, b) => a + b.average_marks, 0) / (students.length || 1)).toFixed(1),
        pass: students.filter(s => s.grade !== 'Fail').length,
        distinction: students.filter(s => s.average_marks >= 90).length
    };

    const gradeData = [
        { name: 'A', value: students.filter(s => s.grade === 'A').length },
        { name: 'B', value: students.filter(s => s.grade === 'B').length },
        { name: 'C', value: students.filter(s => s.grade === 'C').length },
        { name: 'Fail', value: students.filter(s => s.grade === 'Fail').length },
    ];

    const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#ef4444'];

    return (
        <div className="dashboard-page">
            <div className="page-header">
                <h1>Performance Overview</h1>
                <p>System-wide academic data visualization</p>
            </div>

            <div className="stats-grid">
                <div className="metric-card">
                    <div className="metric-icon"><Users /></div>
                    <div className="metric-info">
                        <span className="metric-label">Students</span>
                        <span className="metric-value">{stats.total}</span>
                    </div>
                </div>
                <div className="metric-card">
                    <div className="metric-icon primary"><TrendingUp /></div>
                    <div className="metric-info">
                        <span className="metric-label">Average Score</span>
                        <span className="metric-value">{stats.avg}%</span>
                    </div>
                </div>
                <div className="metric-card">
                    <div className="metric-icon success"><Award /></div>
                    <div className="metric-info">
                        <span className="metric-label">Passing</span>
                        <span className="metric-value">{stats.pass}</span>
                    </div>
                </div>
                <div className="metric-card">
                    <div className="metric-icon warning"><AlertCircle /></div>
                    <div className="metric-info">
                        <span className="metric-label">Distinctions</span>
                        <span className="metric-value">{stats.distinction}</span>
                    </div>
                </div>
            </div>

            <div className="charts-container">
                <div className="chart-wrapper main-chart">
                    <h3>Grade Distribution</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={gradeData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                            <XAxis dataKey="name" stroke="#94a3b8" />
                            <YAxis stroke="#94a3b8" />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                itemStyle={{ color: '#f8fafc' }}
                            />
                            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                                {gradeData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>

                <div className="chart-wrapper side-chart">
                    <h3>Success Ratio</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={gradeData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {gradeData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
