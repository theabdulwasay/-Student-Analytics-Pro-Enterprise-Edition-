import React, { useState } from 'react';
import { useStudents } from '../context/StudentContext';
import { StudentAPI } from '../api/api';
import { Save, X, Plus, AlertCircle, CheckCircle2 } from 'lucide-react';

const AddStudent = () => {
    const { refreshData } = useStudents();
    const [name, setName] = useState('');
    const [marks, setMarks] = useState({
        math: 0, physics: 0, computer: 0, english: 0,
        chemistry: 0, biology: 0, urdu: 0, islamiyat: 0
    });
    const [status, setStatus] = useState(null);

    const handleMarkChange = (subject, val) => {
        setMarks(prev => ({ ...prev, [subject]: parseInt(val) || 0 }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await StudentAPI.create({ name, marks });
            setStatus({ type: 'success', message: 'Student registered successfully!' });
            setName('');
            setMarks({
                math: 0, physics: 0, computer: 0, english: 0,
                chemistry: 0, biology: 0, urdu: 0, islamiyat: 0
            });
            refreshData();
            setTimeout(() => setStatus(null), 3000);
        } catch (err) {
            setStatus({ type: 'error', message: 'Failed to register student.' });
        }
    };

    return (
        <div className="add-student-page">
            <div className="page-header">
                <h1>Add New Record</h1>
                <p>Register a new student and their academic performance</p>
            </div>

            {status && (
                <div className={`status-alert ${status.type}`}>
                    {status.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
                    <span>{status.message}</span>
                </div>
            )}

            <form onSubmit={handleSubmit} className="enterprise-form">
                <div className="form-section">
                    <h3>Basic Information</h3>
                    <div className="form-group full">
                        <label>Full Name</label>
                        <input
                            type="text"
                            placeholder="Enter student's full name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                </div>

                <div className="form-section">
                    <h3>Academic Marks (Max 100)</h3>
                    <div className="marks-input-grid">
                        {Object.keys(marks).map(subject => (
                            <div className="form-group" key={subject}>
                                <label>{subject.charAt(0).toUpperCase() + subject.slice(1)}</label>
                                <input
                                    type="number"
                                    min="0"
                                    max="100"
                                    value={marks[subject]}
                                    onChange={(e) => handleMarkChange(subject, e.target.value)}
                                    required
                                />
                            </div>
                        ))}
                    </div>
                </div>

                <div className="form-footer">
                    <button type="button" className="btn-secondary" onClick={() => window.history.back()}>
                        <X size={18} /> Cancel
                    </button>
                    <button type="submit" className="btn-primary">
                        <Save size={18} /> Save Student Record
                    </button>
                </div>
            </form>
        </div>
    );
};

export default AddStudent;
