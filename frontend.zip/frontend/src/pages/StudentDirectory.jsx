import React, { useState } from 'react';
import { useStudents } from '../context/StudentContext';
import { StudentAPI } from '../api/api';
import { Filter, Search, Edit2, Trash2, Check, X } from 'lucide-react';

const StudentDirectory = () => {
    const { students, loading, refreshData } = useStudents();
    const [search, setSearch] = useState('');
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState('');
    const [editMarks, setEditMarks] = useState({});

    if (loading) return <div className="p-8">Loading Records...</div>;

    const handleDelete = async (id) => {
        if (window.confirm('Permanent action: Delete this student record?')) {
            try {
                await StudentAPI.delete(id);
                refreshData();
            } catch (err) { alert('Delete failed'); }
        }
    };

    const startEdit = (student) => {
        setEditingId(student.id);
        setEditName(student.name);
        setEditMarks(student.marks);
    };

    const cancelEdit = () => {
        setEditingId(null);
    };

    const saveEdit = async (id) => {
        try {
            await StudentAPI.update(id, { name: editName, marks: editMarks });
            setEditingId(null);
            refreshData();
        } catch (err) { alert('Update failed'); }
    };

    const handleMarkEdit = (subject, val) => {
        setEditMarks(prev => ({ ...prev, [subject]: parseInt(val) || 0 }));
    };

    const filtered = students.filter(s =>
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.id.toString().includes(search)
    );

    return (
        <div className="directory-page">
            <div className="page-header">
                <h1>Student Directory</h1>
                <p>Manage and track individual academic records</p>
            </div>

            <div className="table-actions">
                <div className="search-bar">
                    <Search size={18} />
                    <input
                        type="text"
                        placeholder="Search by name or ID..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </div>

            <div className="data-table">
                <table>
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Marks & Analytics</th>
                            <th>Grade</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.map(student => (
                            <tr key={student.id} className={editingId === student.id ? 'editing-row' : ''}>
                                <td>
                                    {editingId === student.id ? (
                                        <input
                                            className="edit-input-name"
                                            value={editName}
                                            onChange={(e) => setEditName(e.target.value)}
                                        />
                                    ) : (
                                        <div className="student-profile">
                                            <div className="avatar">{student.name.charAt(0)}</div>
                                            <div className="info">
                                                <span className="name">{student.name}</span>
                                                <span className="id">ID: #{student.id}</span>
                                            </div>
                                        </div>
                                    )}
                                </td>
                                <td>
                                    {editingId === student.id ? (
                                        <div className="edit-marks-small">
                                            {Object.keys(editMarks).map(sub => (
                                                <div key={sub} className="m-edit">
                                                    <label>{sub[0].toUpperCase()}:</label>
                                                    <input
                                                        type="number"
                                                        value={editMarks[sub]}
                                                        onChange={(e) => handleMarkEdit(sub, e.target.value)}
                                                    />
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <div className="avg-badge">
                                            <div className="progress" style={{ width: `${student.average_marks}%` }}></div>
                                            <span>{student.average_marks}%</span>
                                        </div>
                                    )}
                                </td>
                                <td><span className={`g-badge ${student.grade}`}>{student.grade}</span></td>
                                <td>
                                    <span className={`status ${student.grade === 'Fail' ? 'at-risk' : 'stable'}`}>
                                        {student.grade === 'Fail' ? 'At Risk' : 'Stable'}
                                    </span>
                                </td>
                                <td>
                                    {editingId === student.id ? (
                                        <div className="row-actions">
                                            <button className="icon-btn success" onClick={() => saveEdit(student.id)}><Check size={16} /></button>
                                            <button className="icon-btn" onClick={cancelEdit}><X size={16} /></button>
                                        </div>
                                    ) : (
                                        <div className="row-actions">
                                            <button className="icon-btn" onClick={() => startEdit(student)}><Edit2 size={16} /></button>
                                            <button className="icon-btn danger" onClick={() => handleDelete(student.id)}><Trash2 size={16} /></button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default StudentDirectory;
