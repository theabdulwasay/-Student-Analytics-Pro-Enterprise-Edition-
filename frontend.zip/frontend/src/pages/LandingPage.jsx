import React from 'react';
import { useStudents } from '../context/StudentContext';
import { ChevronRight } from 'lucide-react';

const LandingPage = () => {
    const { login } = useStudents();

    return (
        <div className="landing-page">
            {/* Animated Background Objects */}
            <div className="shape shape-1"></div>
            <div className="shape shape-2"></div>
            <div className="shape shape-3"></div>

            <div className="landing-content">
                <div className="landing-logo">S</div>
                <h1 className="landing-title">Empower Education with <br /> Student Analytics Pro</h1>
                <p className="landing-subtitle">
                    The ultimate enterprise-grade analyzer for modern institutions.
                    Streamline grading, visualize performance, and manage student success
                    with state-of-the-art technology.
                </p>

                <div className="landing-btn-group">
                    <button className="landing-btn pulse" onClick={login}>
                        Launch System <ChevronRight size={24} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LandingPage;
